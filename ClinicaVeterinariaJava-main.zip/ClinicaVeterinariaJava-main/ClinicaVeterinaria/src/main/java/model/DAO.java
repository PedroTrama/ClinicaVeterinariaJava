package model;
public class DAO {
    
}
