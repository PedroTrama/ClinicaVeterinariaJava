package model;
public class ConsultaDAO {
    
}
