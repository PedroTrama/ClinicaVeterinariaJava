package model;
public class TratamentoDAO {
    
}
