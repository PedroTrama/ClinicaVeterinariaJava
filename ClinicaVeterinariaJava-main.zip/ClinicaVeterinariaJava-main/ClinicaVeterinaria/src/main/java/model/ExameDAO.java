package model;
public class ExameDAO {
    
}
