package model;
public class VeterinarioDAO {
    
}
