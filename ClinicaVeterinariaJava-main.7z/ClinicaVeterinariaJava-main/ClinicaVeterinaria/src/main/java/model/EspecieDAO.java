
package model;
public class EspecieDAO {
    
}
