# ClinicaVeterinariaJava
Projeto me Java do zero para a disciplina TT001 do segundo semestre de 2022
